# thoitiet
Crack wps wifi

# Hướng dẫn sơ sài :
* pkg update && pkg upgrade -y
* pkg install root-repo -y
* pip install pycryptodome
* pkg install git tsu python wpa-supplicant pixiewps iw openssl -y
* git clone https://github.com/Thaomtam/thoitiet.git
* cd thoitiet
* chmod +x thoitiet.py
* sudo python thoitiet.py -i wlan0 -K
